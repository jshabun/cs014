#include "MyTree.h"

// Testing (you must implement yours for the perfomance studies)
int main() {
  MyTree tree100;
  MyTree tree1000;
  MyTree tree10000;
  MyTree tree100000;
  
  tree100.generate(100);
  tree1000.generate(1000);
  tree10000.generate(10000);
  tree100000.generate(100000);

  return 0;
}
